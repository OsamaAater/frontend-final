import { useState } from 'react'
import {Table} from '../components/appID'
import { Nav } from '../components/Nav'

export const user = () => {
    return (
        <>
            <Nav />
            <Table />
        </>
      )
};