import { useState } from 'react';
import axios from 'axios';
import '../Css/Login.css';

export const Login = () => {
  const [userId, setUserId] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const handleUserLogin = async () => {
    try {
      // Send a POST request to the backend for authentication
      const response = await axios.post('http://localhost:8080/user', { userId, userPassword });

      // Check if the login was successful based on the response from the backend
      if (response.data.success) {
        // Successful login
        console.log('User login successful');
        setLoginError('Login successful!');
        // Redirect the user to another page
      } else {
        // Invalid credentials
        console.error('Invalid credentials');
        setLoginError('Invalid username or password. Please try again.');
      }
    } catch (error) {
      // Error handling for failed login attempt
      console.error('User login failed', error);
      setLoginError('Login failed. Please try again.');
    }
  };

  return (
      <div className="Login-Wrapper">
        <div className="Login">
          <header className="Login-header">
            <p id='Login-header-text'>IP Whitelist Tracker</p>
            <form onSubmit={handleUserLogin}>
              <label>
                Username:
                <input type="text" name="userId" value={userId} onChange={(e) => setUserId(e.target.value)} />
              </label>
              <br />
              <label>
                Password:
                <input type="password" name="userPassword" value={userPassword} onChange={(e) => setUserPassword(e.target.value)} />
              </label>
              <br />
              <button type="submit">Login</button>
            </form>
            {loginError && <p className="error-message">{loginError}</p>}
          </header>
        </div>
      </div>
  );
};

