import React, { useState } from 'react';
import axios from 'axios';
import DatePicker from 'react-datepicker'; // Import DatePicker
import 'react-datepicker/dist/react-datepicker.css'; // Import DatePicker styles
import { Nav } from '../components/Nav'

export const Add = () => {
  const [formData, setFormData] = useState({
    appInfoUid: '',
    sourceHostname: '',
    sourceIpAddress: '',
    destinationHostName: '',
    destinationIpAddress: '',
    destinationPort: '',
    ipStatus: '',
    createdAt: null, // Changed to null
    createdBy: '',
    modifiedAt: null, // Changed to null
    modifiedBy: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle date changes for "Created At" and "Modified At" fields
  const handleDateChange = (name, date) => {
    setFormData({ ...formData, [name]: date });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/serverinfo', formData);
      alert('Data added successfully!');
      setFormData({
        appInfoUid: '',
        sourceHostname: '',
        sourceIpAddress: '',
        destinationHostName: '',
        destinationIpAddress: '',
        destinationPort: '',
        ipStatus: '',
        createdAt: null,
        createdBy: '',
        modifiedAt: null,
        modifiedBy: ''
      });
    } catch (error) {
      console.error('Error adding data:', error);
      alert('An error occurred while adding data.');
    }
  };

  return (
      <div className="add-page">
        <><Nav /></>
        <h1>Add Data</h1>
        <form onSubmit={handleSubmit}>
          <input type="text" name="appInfoUid" value={formData.appInfoUid} onChange={handleChange} placeholder="App UID(int value)" />
          <input type="text" name="sourceHostname" value={formData.sourceHostname} onChange={handleChange} placeholder="Src. host name" />
          <input type="text" name="sourceIpAddress" value={formData.sourceIpAddress} onChange={handleChange} placeholder="Src. IP address" />
          <input type="text" name="destinationHostName" value={formData.destinationHostName} onChange={handleChange} placeholder="dest. host name" />
          <input type="text" name="destinationIpAddress" value={formData.destinationIpAddress} onChange={handleChange} placeholder="Dest. ip address" />
          <input type="text" name="destinationPort" value={formData.destinationPort} onChange={handleChange} placeholder="Dest. port" />
          <select name="ipStatus" value={formData.ipStatus} onChange={handleChange}>
            <option value="">Select IP Status</option>
            <option value="Active">Active</option>
            <option value="Not Active">Not Active</option>
          </select>
          {/* DatePicker for "Created At" */}
          <DatePicker
              selected={formData.createdAt}
              onChange={(date) => handleDateChange('createdAt', date)}
              placeholderText="Created At"
              showTimeSelect
              timeFormat="HH:mm"
              dateFormat="MMMM d, yyyy h:mm aa"
          />
          {/* DatePicker for "Modified At" */}
          <DatePicker
              selected={formData.modifiedAt}
              onChange={(date) => handleDateChange('modifiedAt', date)}
              placeholderText="Modified At"
              showTimeSelect
              timeFormat="HH:mm"
              dateFormat="MMMM d, yyyy h:mm aa"
          />
          <input type="text" name="createdBy" value={formData.createdBy} onChange={handleChange} placeholder="Created By" />
          <input type="text" name="modifiedBy" value={formData.modifiedBy} onChange={handleChange} placeholder="Modified By" />
          <button type="submit">Submit</button>
        </form>
      </div>
  );
};

export default Add;