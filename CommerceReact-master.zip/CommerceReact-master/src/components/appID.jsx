import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Css/Table.css';

export const Table = () => {
  const [tableData, setTableData] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const [searchInput, setSearchInput] = useState('');
  const [sortCriteria, setSortCriteria] = useState(null);
  const [filterCriteria, setFilterCriteria] = useState('all');
  const [viewRow, setViewRow] = useState(null);
  const [formData, setFormData] = useState({
    createdAt: '',
    createdBy: '',
    modifiedAt: '',
    modifiedBy: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await axios.get('http://localhost:8080/applicationinfos');
      setTableData(response.data);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const handleRowClick = (row) => {
    setSelectedRow(row);
  };

  const handleSearchInputChange = (event) => {
    setSearchInput(event.target.value);
  };

  const handleSort = (criteria) => {
    setSortCriteria(criteria);
  };

  const handleFilterChange = (event) => {
    setFilterCriteria(event.target.value);
  };

  const handleView = (row) => {
    setViewRow(row === viewRow ? null : row);
  };

  const handleSaveEdit = async () => {
    try {
      // Update the tableData with the edited row data
      const updatedTableData = tableData.map((row) => {
        if (row.id === formData.id) {
          return { ...row, ...formData };
        }
        return row;
      });
      setTableData(updatedTableData);
      // Send the edited data to the server for persistence
      await axios.put(`http://localhost:8080/applicationinfo/${formData.id}`, formData);
    } catch (error) {
      console.error('Error saving edit:', error);
    }
  };

  const exportToCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," + tableData.map(row => Object.values(row).join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "table_data.csv");
    document.body.appendChild(link);
    link.click();
  };

  const filteredData = tableData.filter((row) => {
    if (filterCriteria === 'all') {
      return Object.values(row).some((value) =>
        value.toString().toLowerCase().includes(searchInput.toLowerCase())
      );
    } else {
      return row[filterCriteria].toString().toLowerCase().includes(searchInput.toLowerCase());
    }
  });

  const sortedData = sortCriteria
    ? filteredData.slice().sort((a, b) => {
      if (a[sortCriteria] < b[sortCriteria]) return -1;
      if (a[sortCriteria] > b[sortCriteria]) return 1;
      return 0;
    })
    : filteredData;

  return (
    <div className="tableContainer">
      <div className="searchContainer">
        <input
          type="text"
          placeholder="Search..."
          value={searchInput}
          onChange={handleSearchInputChange}
        />
        <select value={filterCriteria} onChange={handleFilterChange}>
          <option value="all">All</option>
          <option value="createdAt">Created At</option>
          <option value="createdBy">Created By</option>
          <option value="modifiedAt">Modified At</option>
          <option value="modifiedBy">Modified By</option>
        </select>
      </div>
      <div className="textFieldsContainer">
        {Object.keys(formData).map(key => (
          <input
            key={key}
            type="text"
            placeholder={key}
            value={formData[key]}
            onChange={(e) => setFormData({...formData, [key]: e.target.value})}
          />
        ))}
        <button onClick={handleSaveEdit}>Save</button>
      </div>
      <button onClick={exportToCSV}>Export to CSV</button>
      <table>
        <thead>
          <tr>
            <th onClick={() => handleSort('createdAt')}>Created At</th>
            <th onClick={() => handleSort('createdBy')}>Created By</th>
            <th onClick={() => handleSort('modifiedAt')}>Modified At</th>
            <th onClick={() => handleSort('modifiedBy')}>Modified By</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {sortedData.map((row, index) => (
            <React.Fragment key={index}>
              <tr
                className={row === selectedRow ? 'selected' : ''}
                onClick={() => handleRowClick(row)}
              >
                <td>{row.createdAt}</td>
                <td>{row.createdBy}</td>
                <td>{row.modifiedAt}</td>
                <td>{row.modifiedBy}</td>
                <td>
                  <button onClick={() => handleSaveEdit(row)}>Edit</button>
                  <button onClick={() => handleView(row)}>View</button>
                </td>
              </tr>
              {viewRow === row && (
                <tr>
                  <td colSpan="5">
                    <p>Created At: {row.createdAt}</p>
                    <p>Created By: {row.createdBy}</p>
                    <p>Modified At: {row.modifiedAt}</p>
                    <p>Modified By: {row.modifiedBy}</p>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};
